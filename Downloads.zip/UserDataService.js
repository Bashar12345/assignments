import http from "../utilities/http.common";

const create = data => http.post("/register", data);

const UserDataService = {
    create
};

export default UserDataService;